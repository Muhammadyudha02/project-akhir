<?php 
$link = mysqli_connect("127.0.0.1", "root", "", "dbperpus");
// mysql_connect('localhost','root','');
// mysql_select_db('dbperpus');
?>